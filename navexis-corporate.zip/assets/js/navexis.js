(function(){
  var d=document; d.documentElement.classList.remove('no-js');
  // mobile nav
  var nav=d.getElementById('nav'), bg=d.querySelector('.burger');
  if(bg&&nav){
    bg.addEventListener('click',function(){var o=nav.classList.toggle('open');bg.setAttribute('aria-expanded',o)});
    d.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){nav.classList.remove('open');bg.setAttribute('aria-expanded','false');bg.focus()}});
  }
  // logo fallback (wordmark) if image missing
  d.querySelectorAll('.brand img').forEach(function(i){
    var f=function(){i.closest('.brand').classList.add('noimg')};
    if(i.complete&&!i.naturalWidth)f(); else i.addEventListener('error',f);
  });
  // hide broken photos, keep the gradient frame
  d.querySelectorAll('.ph img,.media img').forEach(function(i){
    var f=function(){i.style.visibility='hidden'};
    if(i.complete&&!i.naturalWidth)f(); else i.addEventListener('error',f);
  });
  // reveal on scroll
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.1,rootMargin:'0px 0px -40px 0px'});
    d.querySelectorAll('.rv').forEach(function(el){io.observe(el)});
  } else d.querySelectorAll('.rv').forEach(function(el){el.classList.add('in')});
  var y=d.getElementById('yr'); if(y) y.textContent=new Date().getFullYear();
  // contact form
  var f=d.getElementById('cform'); if(!f) return;
  var m=d.getElementById('fmsg');
  function check(fl){var c=fl.querySelector('input,select,textarea'); var ok=c.checkValidity(); fl.classList.toggle('bad',!ok); return ok}
  f.querySelectorAll('.fld').forEach(function(fl){var c=fl.querySelector('input,select,textarea'); c.addEventListener('blur',function(){if(c.value)check(fl)}); c.addEventListener('input',function(){if(fl.classList.contains('bad'))check(fl)})});
  f.addEventListener('submit',function(e){
    e.preventDefault(); var first=null;
    f.querySelectorAll('.fld').forEach(function(fl){if(!check(fl)&&!first)first=fl.querySelector('input,select,textarea')});
    var cb=f.querySelector('.chk input'); if(!cb.checked&&!first)first=cb;
    if(first){first.focus(); if(first===cb)cb.reportValidity(); return}
    var b=f.querySelector('button[type=submit]'), t=b.innerHTML; b.disabled=true; b.textContent=f.dataset.sending; m.className='fmsg';
    fetch(f.action,{method:'POST',body:new FormData(f),headers:{Accept:'application/json'}})
      .then(function(r){if(!r.ok)throw 0; m.textContent=f.dataset.ok; m.className='fmsg ok'; f.reset()})
      .catch(function(){m.textContent=f.dataset.err; m.className='fmsg err'})
      .then(function(){b.disabled=false; b.innerHTML=t; m.focus()});
  });
})();
